/*
 Assignment 2 — Thread Synchronization and Data Races
 CS311 Operating System Fundamentals

 Uses helper functions from user_data.c.

 Initially: no locks → race conditions will occur.
 Students will first add a global mutex for correctness.
 Later, they will explore finer-grained locking approaches.
*/

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include "user_data.h"   // brings in User struct + helper functions


/* TODO (Part 3 - Per-Segment Locks):
 * Implement this function as part of the segment-lock section of the assignment.
 * Each segment contains 100 users (IDs 0-99 -> segment 0, 100-199 -> segment 1, etc.).
 * This function should return which segment a given user ID belongs to.
 */
int seg_index_for_id(int id) {
    // TODO: Compute which segment this id belongs to.
    return 0; // placeholder
}



static User *table = NULL;
static int nthreads = 1;

// --------------------------------------------------------------------
// TODO (Step 1): Add a global mutex lock here for protecting the table.
// Example:
// static pthread_mutex_t global_lock = PTHREAD_MUTEX_INITIALIZER;
// --------------------------------------------------------------------


typedef struct {
    int tid;
    unsigned long long put_time_ns;
    unsigned long long get_time_ns;
    int missing;
} thread_info_t;


// Insert a user record into the shared table
void put_user(int id) {
    User u;
    make_name_email(id, u.name, MAX_NAME, u.email, MAX_EMAIL);
    u.id = id;
    u.valid = 1;

    // ---------------------------------------------------------------
    // TODO (Step 1): Wrap the write to the shared table with the lock.
    // Example:
    // pthread_mutex_lock(&global_lock);
    // table[id] = u;
    // pthread_mutex_unlock(&global_lock);
    // ---------------------------------------------------------------

    table[id] = u;  // initially unprotected (causes race conditions)
}


// Retrieve a user record by ID
int get_user(int id) {
    int found = 0;

    // ---------------------------------------------------------------
    // TODO (Step 1): Lock around the read of the shared table.
    // Example:
    // pthread_mutex_lock(&global_lock);
    // User u = table[id];
    // if (u.valid && u.id == id) found = 1;
    // pthread_mutex_unlock(&global_lock);
    // ---------------------------------------------------------------

    User u = table[id];
    if (u.valid && u.id == id)
        found = 1;

    return found;
}


// Thread function: perform put() and get() phases
void *thread_main(void *arg) {
    thread_info_t *ti = (thread_info_t*)arg;
    int tid = ti->tid;
    int users_per_thread = NUM_USERS / nthreads;
    int start = tid * users_per_thread;
    int end = start + users_per_thread;

    // Phase 1: insert users
    unsigned long long t0 = now_ns();
    for (int id = start; id < end; id++) {
        put_user(id);
    }
    unsigned long long t1 = now_ns();
    ti->put_time_ns = t1 - t0;

    // Phase 2: look up all users
    unsigned long long t2 = now_ns();
    int missing = 0;
    for (int id = 0; id < NUM_USERS; id++) {
        if (!get_user(id)) missing++;
    }
    unsigned long long t3 = now_ns();
    ti->get_time_ns = t3 - t2;
    ti->missing = missing;

    return NULL;
}


void usage(char *prog) {
    fprintf(stderr, "Usage: %s <nthreads>\n", prog);
    exit(1);
}


int main(int argc, char **argv) {
    if (argc < 2) usage(argv[0]);
    nthreads = atoi(argv[1]);
    if (nthreads <= 0) {
        fprintf(stderr, "nthreads must be > 0\n");
        return 1;
    }

    // Allocate shared table
    table = calloc(NUM_USERS, sizeof(User));
    if (!table) {
        perror("calloc");
        return 1;
    }

    pthread_t *threads = malloc(sizeof(pthread_t) * nthreads);
    thread_info_t *tinfo = malloc(sizeof(thread_info_t) * nthreads);

    unsigned long long start_all = now_ns();

    // Launch threads
    for (int i = 0; i < nthreads; i++) {
        tinfo[i].tid = i;
        if (pthread_create(&threads[i], NULL, thread_main, &tinfo[i]) != 0) {
            perror("pthread_create");
            return 1;
        }
    }

    // Wait for threads
    for (int i = 0; i < nthreads; i++) {
        pthread_join(threads[i], NULL);
    }

    unsigned long long end_all = now_ns();

    // Print timing and results
    for (int i = 0; i < nthreads; i++) {
        printf("%d: put time = %.6f s\n", i, tinfo[i].put_time_ns / 1e9);
        printf("%d: lookup time = %.6f s\n", i, tinfo[i].get_time_ns / 1e9);
        printf("%d: %d users missing\n", i, tinfo[i].missing);
    }

    int total_missing = 0;
    for (int i = 0; i < nthreads; i++) total_missing += tinfo[i].missing;
    printf("\nTOTAL users missing (aggregate across threads): %d\n", total_missing);


    printf("\n(no locks yet)\n");
    printf("completion time = %.6f seconds\n", (end_all - start_all) / 1e9);

    free(threads);
    free(tinfo);
    free(table);
    return 0;
}
